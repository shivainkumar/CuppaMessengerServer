package main;

import com.google.gson.Gson;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	public int client_id;
	public User user;
	public Socket socket;
	public InputStream in;
	public OutputStream out;
	public boolean isAuth;
	
	public Client() throws UnknownHostException, IOException {
		user = new User();
		socket = new Socket("localhost", 5000);
		in = socket.getInputStream();
		out = socket.getOutputStream();
	}
	
	public Client(int port) throws UnknownHostException, IOException {
		socket = new Socket("localhost", port);
		in = socket.getInputStream();
		out = socket.getOutputStream();
	}

	
	public void send(Message msg) throws IOException {
		DataOutputStream dout = new DataOutputStream(out);
		Gson gson = new Gson();
		dout.writeUTF( gson.toJson(msg) + "\n");
		dout.flush();
	}

	public void sendToUser(String to, String msg) throws IOException {
		send(new Message(user.username, to, "MSG-TEXT", "user_to_user", msg));
	}

	public void sendToGroup(Conversation convo, String msg) throws IOException {
		send(new Message(user.username, convo.getParticipants().toString(), "MSG-TEXT", "user_to_group", msg));
	}


	public void pulse() throws IOException {
		Message heartbeat = new Message(user.username, "server", "client_status", "heartbeat", "alive");
		send(heartbeat);
	}


}
